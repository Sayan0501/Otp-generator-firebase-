
import './App.css';
import Run from './Run';

function App() {
  return (
    <div className="App">
      <Run/>
    </div>
  );
}

export default App;
